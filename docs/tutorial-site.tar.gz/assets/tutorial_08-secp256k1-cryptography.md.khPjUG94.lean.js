import{C as h,c as k,o as t,ag as i,G as p}from"./chunks/framework.EuUYIJ38.js";const d=JSON.parse('{"title":"Chapter 8: Elliptic Curve Cryptography with secp256k1","description":"","frontmatter":{},"headers":[],"relativePath":"tutorial/08-secp256k1-cryptography.md","filePath":"tutorial/08-secp256k1-cryptography.md"}'),l={name:"tutorial/08-secp256k1-cryptography.md"},g=Object.assign(l,{setup(e){const a=`#import <Foundation/Foundation.h>

// --- MOCK Secp256k1 Implementation ---
// NOTE: This is a simulation for the tutorial runner.
// Real apps must use libsecp256k1!

@interface Secp256k1KeyPair : NSObject
@property (readonly) NSData *privateKey;
@property (readonly) NSData *publicKey;
@property (readonly) NSData *compressedPublicKey;
+ (instancetype)generateKeyPair:(NSError **)error;
- (NSData *)signHash:(NSData *)hash error:(NSError **)error;
- (BOOL)verifySignature:(NSData *)sig forHash:(NSData *)h error:(NSError **)error;
@end

@implementation Secp256k1KeyPair
+ (instancetype)generateKeyPair:(NSError **)error {
    Secp256k1KeyPair *k = [Secp256k1KeyPair new];
    // Mock Keys (32 bytes private, 33 compressed public)
    const char *mockPriv = "12345678901234567890123456789012";
    const char *mockPub  = "0212345678901234567890123456789012"; 
    
    k->_privateKey = [NSData dataWithBytes:mockPriv length:32];
    k->_publicKey = [NSData dataWithBytes:"mock_uncompressed_key_65_bytes..." length:65];
    k->_compressedPublicKey = [NSData dataWithBytes:mockPub length:33];
    return k;
}

- (NSData *)signHash:(NSData *)hash error:(NSError **)error {
    printf("Signing hash: %s\\n", hash.description.UTF8String);
    // Return dummy signature (64 bytes)
    NSMutableData *sig = [NSMutableData dataWithLength:64];
    ((char*)sig.mutableBytes)[0] = 0xAA; // Mock signature byte
    return sig;
}

- (BOOL)verifySignature:(NSData *)sig forHash:(NSData *)h error:(NSError **)error {
    // Mock verification: valid if sig starts with 0xAA
    BOOL valid = (((unsigned char*)sig.bytes)[0] == 0xAA);
    printf("Verifying signature... %s\\n", valid ? "VALID" : "INVALID");
    return valid;
}
@end

int main() {
    @autoreleasepool {
        printf("--- Crypto Signing Demo (Mock) ---\\n");
        
        // 1. Generate Key Pair
        Secp256k1KeyPair *keyPair = [Secp256k1KeyPair generateKeyPair:nil];
        printf("Public Key: %s\\n", keyPair.compressedPublicKey.description.UTF8String);
        
        // 2. Data to Sign (Repository Commit CID)
        NSData *commitHash = [@"commit_hash_data_32_bytes_long!!" dataUsingEncoding:NSUTF8StringEncoding];
        
        // 3. Sign
        NSError *err = nil;
        NSData *signature = [keyPair signHash:commitHash error:&err];
        printf("Signature:  %s\\n", signature.description.UTF8String);
        
        // 4. Verify
        [keyPair verifySignature:signature forHash:commitHash error:&err];
    }
    return 0;
}`;return(r,s)=>{const n=h("ObjcRunner");return t(),k("div",null,[s[0]||(s[0]=i("",21)),p(n,{initialCode:a}),s[1]||(s[1]=i("",55))])}}});export{d as __pageData,g as default};
