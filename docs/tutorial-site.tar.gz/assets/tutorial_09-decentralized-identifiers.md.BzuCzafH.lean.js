import{C as t,c as e,o as l,ag as i,G as p}from"./chunks/framework.EuUYIJ38.js";const o=JSON.parse('{"title":"Chapter 9: Decentralized Identifiers (DIDs)","description":"","frontmatter":{},"headers":[],"relativePath":"tutorial/09-decentralized-identifiers.md","filePath":"tutorial/09-decentralized-identifiers.md"}'),h={name:"tutorial/09-decentralized-identifiers.md"},E=Object.assign(h,{setup(k){const a=`#import <Foundation/Foundation.h>

// --- Simplified Base58 Implementation ---
static const char base58Alphabet[] = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz";

NSData *base58Decode(NSString *string) {
    if (string.length == 0) return [NSData data];
    NSUInteger zeroCount = 0;
    while (zeroCount < string.length && [string characterAtIndex:zeroCount] == '1') zeroCount++;
    
    NSUInteger maxSize = string.length * 733 / 1000 + 1;
    uint8_t *output = calloc(maxSize, 1);
    NSUInteger outputLength = 1;
    
    for (NSUInteger i = zeroCount; i < string.length; i++) {
        const char *p = strchr(base58Alphabet, [string characterAtIndex:i]);
        if (!p) { free(output); return nil; }
        uint8_t digit = p - base58Alphabet;
        uint16_t carry = digit;
        for (NSUInteger j = 0; j < outputLength; j++) {
            uint32_t product = output[j] * 58 + carry;
            output[j] = product % 256;
            carry = product / 256;
        }
        while (carry) output[outputLength++] = carry % 256;
    }
    
    NSMutableData *res = [NSMutableData dataWithLength:zeroCount + outputLength];
    uint8_t *bytes = res.mutableBytes;
    for (NSUInteger i = 0; i < outputLength; i++) bytes[zeroCount + i] = output[outputLength - 1 - i];
    free(output);
    return res;
}

void parseDIDKey(NSString *did) {
    printf("Parsing: %s\\n", did.UTF8String);
    
    if (![did hasPrefix:@"did:key:z"]) {
        printf("Error: Not a valid did:key (must start with did:key:z)\\n");
        return;
    }
    
    NSString *encoded = [did substringFromIndex:9]; // Skip "did:key:z"
    NSData *data = base58Decode(encoded);
    if (!data) { printf("Error: Invalid Base58 encoding\\n"); return; }
    
    printf("Raw Bytes: %lu bytes\\n", (unsigned long)data.length);
    
    // Check Multicodec Prefix (secp256k1 = 0xe7 0x01)
    const uint8_t *bytes = data.bytes;
    if (data.length > 2 && bytes[0] == 0xE7 && bytes[1] == 0x01) {
        printf("Key Type:  secp256k1 (0xe701)\\n");
        NSData *pubKey = [data subdataWithRange:NSMakeRange(2, data.length - 2)];
        printf("Public Key: %s\\n", pubKey.description.UTF8String);
    } else {
        printf("Key Type:  Unknown Multicodec (0x%02X%02X)\\n", bytes[0], bytes[1]);
    }
    printf("\\n");
}

int main() {
    @autoreleasepool {
        // Valid secp256k1 DID
        parseDIDKey(@"did:key:zQ3shokFTS3brHcDQrn82RUDfCZESWL1ZdCEJwekUDPQiYBme");
        
        // Another example (Ed25519 usually uses 0xed01)
        // Let's just try parsing the first one again to verify
    }
    return 0;
}`;return(r,s)=>{const n=t("ObjcRunner");return l(),e("div",null,[s[0]||(s[0]=i("",175)),p(n,{initialCode:a}),s[1]||(s[1]=i("",177))])}}});export{o as __pageData,E as default};
