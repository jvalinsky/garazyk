/**
 * ATProto file upload plugin for JupyterLab.
 *
 * Adds commands and file type registrations for uploading ATProto-relevant
 * files (.car, .cbor, .cid) into the JupyterLite virtual filesystem.
 * Users can then read these files from ObjC kernel code.
 *
 * Commands:
 *   - atproto:upload-file — opens a file picker for .car/.cbor/.cid files
 *
 * File types registered:
 *   - CAR Archive (.car) — application/vnd.ipld.car
 *   - CBOR data (.cbor) — application/cbor
 *   - CID (.cid) — application/vnd.atproto.cid
 */
import { JupyterFrontEndPlugin } from '@jupyterlab/application';
declare const plugin: JupyterFrontEndPlugin<void>;
export default plugin;
