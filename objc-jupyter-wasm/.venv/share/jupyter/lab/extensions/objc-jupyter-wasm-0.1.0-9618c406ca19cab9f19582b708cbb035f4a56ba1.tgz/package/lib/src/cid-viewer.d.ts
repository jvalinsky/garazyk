/**
 * CID decoder viewer for JupyterLab.
 *
 * Renders CID strings (bafyrei..., Qm...) as structured tables showing
 * version, codec, multihash algorithm, and digest. Also works as a
 * document viewer for .cid files.
 *
 * MIME type: application/vnd.atproto.cid
 */
import { Widget } from '@lumino/widgets';
import { IRenderMime } from '@jupyterlab/rendermime';
export declare class CidViewer extends Widget implements IRenderMime.IRenderer {
    private _mimeType;
    constructor(options: IRenderMime.IRendererOptions);
    renderModel(model: IRenderMime.IMimeModel): Promise<void>;
}
export declare const cidViewerExtension: IRenderMime.IExtension;
export default cidViewerExtension;
