export class WasiProcExitError extends Error {
    constructor(code: any);
    code: any;
}
export class ObjcWasmKernel {
    static create(runtimeManifestOrUrl?: {
        kernelWasmUrl: string;
        runtimeVersion: string;
        sha256: string;
        maxRequestBytes: number;
        maxResponseBytes: number;
        softTimeoutMs: number;
        hardTimeoutMs: number;
    }, options?: {}): Promise<ObjcWasmKernel>;
    static _createHostImports(onStream: any): {
        imports: {
            stream(kind: any, ptr: any, len: any): void;
            should_interrupt(): 0 | 1;
            json_parse(ptr: any, len: any): any;
            json_stringify(objMarker: any, outPtr: any, outLen: any): number;
            fetch(taskId: any, urlPtr: any, methodPtr: any, headersJsonPtr: any, bodyPtr: any, bodyLen: any): number;
            sha256(dataPtr: any, dataLen: any, outPtr: any, outCap: any): number;
            random_bytes(outPtr: any, count: any): any;
            hmac_sha256(keyPtr: any, keyLen: any, dataPtr: any, dataLen: any, outPtr: any, outCap: any): number;
            base32_encode(dataPtr: any, dataLen: any, outPtr: any, outCap: any): number;
            base32_decode(strPtr: any, strLen: any, outPtr: any, outCap: any): number;
            base58btc_encode(dataPtr: any, dataLen: any, outPtr: any, outCap: any): number;
            base58btc_decode(strPtr: any, strLen: any, outPtr: any, outCap: any): number;
            cbor_encode(jsonPtr: any, jsonLen: any, outPtr: any, outCap: any): number;
            cbor_decode(dataPtr: any, dataLen: any, outPtr: any, outCap: any): number;
        };
        bindMemory(nextMemory: any): void;
        bindExports(nextExports: any): void;
        setStreamListener(nextListener: any): void;
        setInterruptBuffer(sharedBuffer: any): void;
        beginExecute(): void;
        requestSoftInterrupt(): boolean;
        clearInterrupt(): void;
        drainStreams(): any[];
        emitText(name: any, text: any): void;
        flushPending(): void;
    };
    static _createWasiImports(host?: null): {
        imports: {
            fd_close(fd: any): number;
            fd_seek(fd: any): number;
            fd_write(fd: any, iovs_ptr: any, iovs_count: any, nwritten_ptr: any): number;
            fd_read(fd: any, iovs_ptr: any, iovs_count: any, nread_ptr: any): number;
            proc_exit(code: any): never;
            environ_sizes_get(count_ptr: any, buf_ptr: any): number;
            environ_get(): number;
            args_sizes_get(argc_ptr: any, argv_buf_size_ptr: any): number;
            args_get(): number;
            fd_fdstat_get(fd: any, stat_ptr: any): number;
            random_get(buf_ptr: any, buf_len: any): number;
            clock_time_get(clock_id: any, precision: any, time_ptr: any): number;
            sched_yield(): number;
            poll_oneoff(in_ptr: any, out_ptr: any, nsubscriptions: any, nevents_ptr: any): number;
            fd_prestat_get(): number;
            fd_prestat_dir_name(): number;
        };
        bindMemory(nextMemory: any): void;
        drainStreams(): {
            name: string;
            text: string;
        }[];
    };
    constructor(instance: any, runtimeManifest: any, host: any, wasi: any);
    instance: any;
    runtimeManifest: any;
    exports: any;
    host: any;
    wasi: any;
    encoder: TextEncoder;
    decoder: TextDecoder;
    setInterruptBuffer(sharedBuffer: any): void;
    setStreamListener(listener: any): void;
    requestSoftInterrupt(): any;
    clearInterrupt(): void;
    kernelInfo(): any;
    execute(code: any, cellId: any): Promise<any>;
    complete(code: any, cursorPos: any): any;
    inspect(code: any, cursorPos: any, detailLevel: any): any;
    callJsonWithoutRequest(exportName: any): any;
    callJsonWithRequest(exportName: any, payload: any): any;
    allocBytes(length: any): any;
    allocU32Slot(): any;
    writeBytes(ptr: any, bytes: any): void;
    writeU32(ptr: any, value: any): void;
    readU32(ptr: any): number;
    readUtf8(ptr: any, length: any): string;
}
