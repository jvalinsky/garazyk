import { CompileRequest, CompileResponse, CompileSuccessResponse } from './runtime-support';
export declare function assertCompileResponse(value: unknown): asserts value is CompileResponse;
export declare function compileObjectiveC(request: CompileRequest, endpoint?: string): Promise<CompileResponse>;
export declare function isCompileCacheHit(response: CompileResponse): response is CompileSuccessResponse;
