export type TransportCode = 0 | 1 | 2 | 3 | 4 | 5;
export declare const TRANSPORT_CODE: {
    readonly OK: 0;
    readonly INVALID_ARGUMENT: 1;
    readonly REQUEST_TOO_LARGE: 2;
    readonly RESPONSE_TOO_LARGE: 3;
    readonly OOM: 4;
    readonly INTERNAL_ERROR: 5;
};
export type RuntimeManifest = {
    kernelWasmUrl: string;
    runtimeVersion: string;
    sha256: string;
    maxRequestBytes: number;
    maxResponseBytes: number;
    softTimeoutMs: number;
    hardTimeoutMs: number;
};
export type CompileMode = 'default' | 'force-rebuild';
export type CompileDiagnostic = {
    severity: 'error' | 'warning' | 'note';
    message: string;
    line: number;
    column: number;
    endLine: number;
    endColumn: number;
    code?: string;
    file?: string;
};
export type CompileRequest = {
    source: string;
    sessionId: string;
    cellId: string;
    workingDirectory: string;
    contextHash: string;
    sdkVersion: string;
    abiTarget: 'wasm32-unknown-emscripten';
    compileMode: CompileMode;
};
export type CompileSuccessResponse = {
    status: 'ok';
    cacheKey: string;
    artifactUrl: string;
    artifactSha256: string;
    runSymbol: string;
    sourceMapUrl: string | null;
    debugMapUrl: string | null;
    diagnostics: CompileDiagnostic[];
};
export type CompileErrorResponse = {
    status: 'error';
    diagnostics: CompileDiagnostic[];
};
export type CompileResponse = CompileSuccessResponse | CompileErrorResponse;
export declare function assertRuntimeManifest(value: unknown): asserts value is RuntimeManifest;
export declare function fetchRuntimeManifest(manifestUrl: string): Promise<RuntimeManifest>;
export declare function clearRuntimeCache(manifestUrl: string): Promise<number>;
export declare function transportErrorMessage(code: TransportCode, context: string): string;
