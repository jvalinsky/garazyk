import { BaseKernel } from '@jupyterlite/kernel';
import { KernelMessage } from '@jupyterlab/services';
import type { RuntimeManifest } from './runtime-support';
type ObjcKernelOptions = {
    runtimeManifest: RuntimeManifest;
    runtimeManifestUrl: string;
};
export declare class ObjcKernel extends BaseKernel {
    private _worker;
    private _pending;
    private _nextMessageId;
    private _workerGeneration;
    private _ready;
    private _infoReply;
    private _sendKernelMessage;
    private _objcExecutionCount;
    private _objcHistory;
    private _runtimeManifest;
    private _runtimeManifestUrl;
    private _interruptBuffer;
    private _interruptView;
    constructor(options: any, kernelOptions: ObjcKernelOptions);
    get ready(): Promise<void>;
    get executionCount(): number;
    handleMessage(msg: KernelMessage.IMessage): Promise<void>;
    kernelInfoRequest(): Promise<any>;
    executeRequest(content: KernelMessage.IExecuteRequestMsg['content']): Promise<any>;
    completeRequest(content: {
        code: string;
        cursor_pos: number;
    }): Promise<any>;
    inspectRequest(content: {
        code: string;
        cursor_pos: number;
        detail_level: number;
    }): Promise<any>;
    isCompleteRequest(content: {
        code: string;
    }): Promise<any>;
    commInfoRequest(_content: any): Promise<any>;
    inputReply(_content: any): void;
    commOpen(_msg: any): Promise<void>;
    commMsg(_msg: any): Promise<void>;
    commClose(_msg: any): Promise<void>;
    dispose(): void;
    private _createWorker;
    private _initializeWorker;
    private _restartWorker;
    private _ensureReady;
    private _handleExecute;
    private _executeContent;
    private _normalizeExecuteReply;
    private _handleCommInfo;
    private _handleHistory;
    private _handleInterrupt;
    private _sendStatus;
    private _sendExecuteInput;
    private _sendExecuteReply;
    private _request;
    private _onWorkerMessage;
    private _resetInterruptFlag;
}
export {};
